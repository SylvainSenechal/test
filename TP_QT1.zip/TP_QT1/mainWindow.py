#import sys
#from PyQt5.QtWidgets import *


#class MainWindow(QMainWindow):
#	
	##############
#	def __init__(self):
#		print("constructeur de la class MainWindow")
#
#
#	###############
#	def open(self):
#		print("Open...")
#	
#	###############
#	def save():
#		print("Save")		
#
#	###############
#	def quit():
#		print("Quit")		



def main(args):
	print("Hello World")
	
	

if __name__ == "__main__":
	main(sys.argv) 